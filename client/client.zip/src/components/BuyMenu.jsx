import React from 'react';

const BuyMenu = () => {
    return (
        <div>
            
        </div>
    );
};

export default BuyMenu;