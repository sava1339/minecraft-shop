import React from 'react';

const Error = () => {
    return (
        <div className="text-center pt-10 text-[32px]">
            Страница не найдена!
        </div>
    );
};

export default Error;